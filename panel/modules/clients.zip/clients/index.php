<?php
/**
 * Clients Module Entry Point
 * Redirect to list page
 */

header('Location: /panel/modules/clients/list.php');
exit;